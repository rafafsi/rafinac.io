const Container = ({ children }) => {
  return (
    <div className="container-fluid text-center bg-view p-5">{children}</div>
  );
};

export default Container;
